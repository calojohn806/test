#!/bin/bash

# 需要以 root 权限运行
if [ "$(id -u)" != "0" ]; then
   echo "这个脚本需要以 root 权限运行。" 1>&2
   exit 1
fi

# 判断是 CentOS 还是 Ubuntu
if [ -f /etc/centos-release ]; then
    OS="CentOS"
elif [ -f /etc/lsb-release ]; then
    OS="Ubuntu"
else
    echo "不支持的 Linux 发行版。"
    exit 1
fi


# 函数用于重命名命令
rename_command() {
    local original_command=$1
    local new_name=$2

    # 检查是否为内置命令或别名
    command_type=$(type -t "$original_command")

    case $command_type in
        "file")
            # 如果是文件，则移动
            mv "/usr/bin/$original_command" "/usr/local/bin/$new_name"
            ;;
        "builtin" | "alias")
            # 如果是内置命令或别名，则修改 .bashrc
            echo "alias $new_name='$original_command'" >> ~/.bashrc
            ;;
        *)
            echo "Command $original_command not found."
            ;;
    esac
}

# 调用函数来重命名命令
rename_command "ll" "chakanxiangxi"
rename_command "la" "chakanxijie"
rename_command "rm" "delete"
rename_command "find" "chazhao"
rename_command "history" "lishi"
rename_command "top" "dingbu"
rename_command "free" "mianfei"
rename_command "lsof" "chakanquanbu"
rename_command "time" "shijian"
rename_command "wget" "dedao"
rename_command "curl" "dedao0"
rename_command "netstat" "wanglu"
rename_command "which" "na"
rename_command "whereis" "zaishena"
rename_command "locate" "zhao"
rename_command "top" "dingbu"
rename_command "crontab" "dingshi"
rename_command "iostat" "yingpan"
# ... 以此类推，为其他命令重复这个过程

# 重新加载 .bashrc
source ~/.bashrc

if [ "$OS" = "CentOS" ]; then
    rename_command "yum" "gengxing"
    mv /usr/bin/yum /usr/local/bin/gengxing
elif [ "$OS" = "Ubuntu" ]; then
    rename_command "apt" "gengxing"
    rename_command "apt-get" "xiazaiget"
    mv /usr/bin/apt /usr/local/bin/xiazai
    mv /usr/bin/apt-get /usr/local/bin/xiazaiget
fi

# 阻止用户重新安装被重命名的命令
# 对于 CentOS
if [ "$OS" = "CentOS" ]; then
    # 通过 yum 配置阻止 coreutils 等软件包的安装
    echo "exclude=coreutils*" >> /etc/yum.conf
fi

# 对于 Ubuntu
if [ "$OS" = "Ubuntu" ]; then
    # 创建一个持久的 APT 配置文件来阻止 coreutils 等软件包的安装
    echo 'Package: coreutils\nPin: version *\nPin-Priority: -1' > /etc/apt/preferences.d/block-coreutils
fi

rename_command "mv" "yidong"

echo "所有更改已应用。"

